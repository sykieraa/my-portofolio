export interface ProjectItem {
  id: string;
  title: string;
  shortDesc: string;
  fullDesc: string;
  category: string;
  featured: boolean;
  image: string;
  technologies: string[];
  stats: Array<{ label: string; value: string }>;
  keyFeatures: string[];
  links: {
    demo?: string;
    github?: string;
  };
}

export const projectsData: ProjectItem[] = [
  {
    id: "project-01",
    title: "Project Portofolio & Interactive 3D Card",
    shortDesc: "Portofolio adalah kumpulan dokumen, karya, proyek, atau pencapaian terbaik seseorang yang disusun secara sistematis.",
    fullDesc: "Modern developer portfolio featuring hanging lanyard physics, smooth tab transitions, custom micro-interactions, and a minimalist editorial aesthetic. Built with React, TypeScript, Tailwind CSS, and Framer Motion.",
    category: "Portfolio & Creative Tech",
    featured: true,
    image: "/assets/projects/project-01.webp",
    technologies: ["React.js", "TypeScript", "Tailwind CSS", "Framer Motion", "Vite"],
    stats: [
      { label: "Performance", value: "99/100" },
      { label: "Motion Framerate", value: "60 FPS" },
      { label: "Responsive", value: "100%" },
    ],
    keyFeatures: [
      "Physical hanging ID lanyard with 3D tilt and spring inertia",
      "Staggered cinematic entrance timelines",
      "Horizontal project and certificate carousels with center magnification",
      "Interactive tech stack showcase with custom brand iconography",
      "Seamless dark-mode editorial aesthetic",
    ],
    links: {
      demo: "https://rifqi.dev",
      github: "https://github.com/rifqidev/portfolio-website",
    },
  },
  {
    id: "project-02",
    title: "SaaS Cloud Analytics & Telemetry Engine",
    shortDesc: "High-performance real-time telemetry dashboard monitoring server clusters, latency graphs, and database traffic.",
    fullDesc: "An enterprise-grade monitoring dashboard with live WebSocket telemetry, drill-down metrics, customizable widget boards, and automated anomaly alert thresholds.",
    category: "Fullstack / Cloud",
    featured: true,
    image: "/assets/projects/project-02.webp",
    technologies: ["Next.js", "TypeScript", "Tailwind CSS", "Recharts", "Prisma", "PostgreSQL"],
    stats: [
      { label: "Data Latency", value: "< 15ms" },
      { label: "Active Nodes", value: "12,000+" },
      { label: "Uptime", value: "99.99%" },
    ],
    keyFeatures: [
      "Real-time WebSocket data stream integration",
      "Interactive SVG time-series charts with zoom and pan",
      "Role-based access control (RBAC) and team workspaces",
      "Automated alerting via webhook and email integrations",
      "Exportable PDF and CSV compliance audit reports",
    ],
    links: {
      demo: "https://cloud-telemetry-demo.rifqi.dev",
      github: "https://github.com/rifqidev/cloud-telemetry-engine",
    },
  },
  {
    id: "project-03",
    title: "E-Commerce Headless Storefront & Checkout",
    shortDesc: "Ultra-fast headless commerce platform with instant search, optimistic cart state, and localized currency checkout.",
    fullDesc: "A blazing fast headless e-commerce experience designed for high-conversion fashion and apparel brands. Includes instant client-side filtering, persistent cart synchronization, and Stripe checkout.",
    category: "Frontend / E-Commerce",
    featured: false,
    image: "/assets/projects/project-03.webp",
    technologies: ["React.js", "TypeScript", "Tailwind CSS", "Zustand", "Stripe API"],
    stats: [
      { label: "Lighthouse Score", value: "100" },
      { label: "Search Speed", value: "8ms" },
      { label: "Conversion Rate", value: "+32%" },
    ],
    keyFeatures: [
      "Zero-latency search with client-side fuzzy indexing",
      "Smooth cart drawer with optimistic item updates",
      "Stripe Elements checkout with one-click payment support",
      "Product image zoom gallery with 3D product previews",
      "Fully responsive mobile-first drawer navigation",
    ],
    links: {
      demo: "https://commerce-storefront.rifqi.dev",
      github: "https://github.com/rifqidev/headless-storefront",
    },
  },
  {
    id: "project-04",
    title: "AI Prompt Engineering Studio & Playground",
    shortDesc: "Collaborative prompt evaluation workspace for benchmarking LLMs, comparing outputs, and managing template versions.",
    fullDesc: "A developer tool designed to test, parameterize, and version-control complex LLM system prompts across multiple model providers simultaneously.",
    category: "AI & Developer Tools",
    featured: false,
    image: "/assets/projects/project-04.webp",
    technologies: ["React.js", "TypeScript", "Tailwind CSS", "Monaco Editor", "OpenAI SDK"],
    stats: [
      { label: "Token Profiler", value: "Realtime" },
      { label: "Model Adapters", value: "8+" },
      { label: "Prompt Tests", value: "50k+" },
    ],
    keyFeatures: [
      "Side-by-side model response diff comparison",
      "Token usage & cost calculation breakdowns",
      "Syntax highlighted Monaco editor with JSON schema validation",
      "One-click cURL and TypeScript SDK snippet export",
      "Local browser storage persistence with exportable JSON workspace",
    ],
    links: {
      demo: "https://ai-prompt-studio.rifqi.dev",
      github: "https://github.com/rifqidev/ai-prompt-studio",
    },
  },
  {
    id: "project-05",
    title: "Fintech Mobile Banking App & Ledger",
    shortDesc: "Encrypted peer-to-peer transaction portal with instant QR settlements and predictive spending insights.",
    fullDesc: "A clean digital banking interface featuring instant contact-to-contact transfers, recurring bill automation, virtual card generation, and categorized budget visualizers.",
    category: "Fintech / Web App",
    featured: false,
    image: "/assets/projects/project-05.webp",
    technologies: ["React.js", "TypeScript", "Tailwind CSS", "Framer Motion", "Chart.js"],
    stats: [
      { label: "Encryption", value: "AES-256" },
      { label: "Settlement", value: "Instant" },
      { label: "Security Score", value: "A+" },
    ],
    keyFeatures: [
      "Dynamic interactive card flip and frozen card toggling",
      "Monthly categorized spending breakdown with interactive radar charts",
      "QR Code generation and scanner mockup interface",
      "Biometric authentication simulation and transaction pin flow",
      "Exportable bank statements in PDF format",
    ],
    links: {
      demo: "https://fintech-portal.rifqi.dev",
      github: "https://github.com/rifqidev/fintech-banking-portal",
    },
  },
  {
    id: "project-06",
    title: "Real-Time 3D Product Configurator",
    shortDesc: "WebGL product customizer with dynamic physical material shaders, studio lighting controls, and glTF asset export.",
    fullDesc: "An immersive 3D customization application enabling users to tweak materials, textures, and geometry presets in real-time with realistic PBR lighting calculations.",
    category: "Three.js / Creative Dev",
    featured: false,
    image: "/assets/projects/project-06.webp",
    technologies: ["Three.js", "React.js", "TypeScript", "Tailwind CSS", "GLSL Shaders"],
    stats: [
      { label: "PBR Materials", value: "30+" },
      { label: "Rendering Rate", value: "60 FPS" },
      { label: "Asset Size", value: "< 2MB" },
    ],
    keyFeatures: [
      "Real-time HDR environment reflections and shadow casting",
      "Dynamic colorway and material texture swapping",
      "Orbit controls with smooth inertial damping and camera presets",
      "High-resolution 4K screenshot snapshot generator",
      "Direct glTF 3D model export capability",
    ],
    links: {
      demo: "https://3d-configurator.rifqi.dev",
      github: "https://github.com/rifqidev/3d-product-configurator",
    },
  },
];
