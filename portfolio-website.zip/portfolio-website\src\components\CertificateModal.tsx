import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ExternalLink, ShieldCheck } from 'lucide-react';
import type { CertificateItem } from '../data/certificates';
import { easeSmooth } from '../utils/animationVariants';

interface CertificateModalProps {
  certificate: CertificateItem | null;
  onClose: () => void;
}

export const CertificateModal: React.FC<CertificateModalProps> = ({
  certificate,
  onClose,
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };

    if (certificate) {
      window.addEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'hidden';
    }

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [certificate, onClose]);

  if (!certificate) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 md:p-8 overflow-y-auto">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.4 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/85 backdrop-blur-xl"
        />

        {/* Modal Content */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ duration: 0.5, ease: easeSmooth }}
          className="relative z-10 w-full max-w-4xl rounded-[32px] bg-[#0d0d11] border border-white/15 shadow-[0_30px_90px_rgba(0,0,0,0.95)] p-6 sm:p-8 overflow-hidden text-white"
        >
          {/* Top Bar */}
          <div className="flex items-center justify-between pb-5 border-b border-white/[0.08]">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              <span className="font-mono text-xs text-neutral-400 uppercase tracking-widest font-semibold">
                Official Credential Verification
              </span>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-full bg-white/[0.08] hover:bg-white/20 border border-white/15 text-neutral-300 hover:text-white transition-all"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Certificate Image Frame */}
          <div className="mt-6 rounded-2xl overflow-hidden bg-white p-2 shadow-2xl border border-white/20">
            <img
              src={certificate.image}
              alt={certificate.title}
              className="w-full h-auto max-h-[55vh] object-contain mx-auto"
            />
          </div>

          {/* Certificate Metadata */}
          <div className="mt-6 flex flex-col md:flex-row md:items-center justify-between gap-4 pt-4 border-t border-white/[0.08]">
            <div className="space-y-1">
              <h3 className="font-display text-lg sm:text-xl font-bold text-white uppercase tracking-wide">
                {certificate.title}
              </h3>
              <p className="font-mono text-xs text-neutral-400">
                Issued by <span className="text-white font-medium">{certificate.issuer}</span> • {certificate.date}
              </p>
              <p className="font-mono text-[11px] text-neutral-500">
                Credential ID: <span className="text-neutral-300">{certificate.credentialId}</span>
              </p>
            </div>

            <div className="flex items-center gap-3">
              <a
                href={certificate.image}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-white text-black font-semibold text-xs hover:bg-neutral-200 transition-all shadow-md"
              >
                <span>View Full Asset</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
