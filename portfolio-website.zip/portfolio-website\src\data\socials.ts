export interface SocialLink {
  id: string;
  name: string;
  url: string;
  handle: string;
  icon: string;
  color?: string;
}

export const socialsData: SocialLink[] = [
  {
    id: "github",
    name: "GitHub",
    url: "https://github.com/rifqidev",
    handle: "@rifqidev",
    icon: "Github",
    color: "#FFFFFF",
  },
  {
    id: "linkedin",
    name: "LinkedIn",
    url: "https://linkedin.com/in/rifqi-muhammad-aliya",
    handle: "Rifqi Muhammad Aliya",
    icon: "Linkedin",
    color: "#0A66C2",
  },
  {
    id: "instagram",
    name: "Instagram",
    url: "https://instagram.com/rifqi.dev",
    handle: "@rifqi.dev",
    icon: "Instagram",
    color: "#E4405F",
  },
  {
    id: "email",
    name: "Email",
    url: "mailto:rifqidev.contact@gmail.com",
    handle: "rifqidev.contact@gmail.com",
    icon: "Mail",
    color: "#3B82F6",
  },
  {
    id: "x",
    name: "X / Twitter",
    url: "https://x.com/rifqidev",
    handle: "@rifqidev",
    icon: "Twitter",
    color: "#1DA1F2",
  },
  {
    id: "discord",
    name: "Discord",
    url: "https://discord.com/users/rifqidev",
    handle: "rifqi#1337",
    icon: "MessageSquare",
    color: "#5865F2",
  },
];
