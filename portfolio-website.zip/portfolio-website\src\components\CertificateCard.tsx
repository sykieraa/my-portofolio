import React from 'react';
import { motion } from 'framer-motion';
import { Award, Eye } from 'lucide-react';
import type { CertificateItem } from '../data/certificates';
import { easeSmooth } from '../utils/animationVariants';

interface CertificateCardProps {
  certificate: CertificateItem;
  isCenter: boolean;
  onSelect: (certificate: CertificateItem) => void;
}

export const CertificateCard: React.FC<CertificateCardProps> = ({
  certificate,
  isCenter,
  onSelect,
}) => {
  return (
    <motion.div
      animate={{
        scale: isCenter ? 1.04 : 0.94,
        opacity: isCenter ? 1 : 0.6,
      }}
      transition={{ duration: 0.5, ease: easeSmooth }}
      onClick={() => onSelect(certificate)}
      className={`group cursor-pointer relative w-[300px] sm:w-[340px] md:w-[380px] flex-shrink-0 rounded-[28px] overflow-hidden transition-all duration-500 flex flex-col justify-between ${
        isCenter
          ? 'bg-[#0e0e12] border border-white/20 shadow-[0_20px_50px_-15px_rgba(0,0,0,0.9),0_0_30px_rgba(255,255,255,0.06)] ring-1 ring-white/10'
          : 'bg-[#0a0a0d] border border-white/[0.07] shadow-xl hover:border-white/15'
      }`}
    >
      {/* Top Certificate Document Preview */}
      <div className="p-4 pb-0">
        <div className="relative aspect-[1.42/1] w-full rounded-[18px] overflow-hidden bg-white p-2 shadow-inner group-hover:scale-[1.02] transition-transform duration-500">
          <img
            src={certificate.image}
            alt={certificate.title}
            className="w-full h-full object-contain"
            loading="lazy"
          />

          {/* Hover Overlay with Eye Icon */}
          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center backdrop-blur-[1px]">
            <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-black/80 text-white font-mono text-xs border border-white/20">
              <Eye className="w-3.5 h-3.5" />
              <span>Preview</span>
            </div>
          </div>
        </div>
      </div>

      {/* Certificate Meta Details */}
      <div className="p-5 flex flex-col justify-between space-y-3">
        <div className="space-y-1.5 text-center">
          <h3 className="font-display text-sm sm:text-base font-bold text-white tracking-wide uppercase line-clamp-2 leading-snug">
            {certificate.title}
          </h3>
          <p className="font-mono text-[11px] text-neutral-400">
            {certificate.issuer} • {certificate.date}
          </p>
        </div>

        {/* Action Button */}
        <div className="pt-2 border-t border-white/[0.06] flex items-center justify-center">
          <span className="font-mono text-[11px] text-neutral-400 group-hover:text-white transition-colors flex items-center gap-1.5">
            <Award className="w-3.5 h-3.5 text-amber-400" />
            <span>Click to view credential</span>
          </span>
        </div>
      </div>
    </motion.div>
  );
};
