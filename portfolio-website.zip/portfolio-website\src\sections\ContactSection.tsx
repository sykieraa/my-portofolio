import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Copy, Check, Send, ArrowUpRight } from 'lucide-react';
import confetti from 'canvas-confetti';
import { socialsData } from '../data/socials';
import { easeSmooth } from '../utils/animationVariants';

export const ContactSection: React.FC = () => {
  const [copied, setCopied] = useState(false);
  const [formState, setFormState] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleCopyEmail = () => {
    navigator.clipboard.writeText('rifqidev.contact@gmail.com');
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitted(true);
      confetti({
        particleCount: 70,
        spread: 60,
        origin: { y: 0.7 },
        colors: ['#3b82f6', '#ffffff', '#60a5fa'],
      });
      setTimeout(() => {
        setSubmitted(false);
        setFormState({ name: '', email: '', subject: '', message: '' });
      }, 4000);
    }, 1200);
  };

  return (
    <section
      id="contact"
      className="relative min-h-screen w-full flex flex-col justify-center py-24 sm:py-32 px-6 sm:px-10 lg:px-16 bg-[#050505] overflow-hidden"
    >
      {/* Background Grid & Radial Accents */}
      <div className="absolute inset-0 bg-tech-grid opacity-30 pointer-events-none" />
      <div className="absolute bottom-1/4 right-10 w-96 h-96 bg-blue-600/[0.03] rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 max-w-6xl mx-auto w-full space-y-12">
        
        {/* Header */}
        <div className="flex flex-col items-center text-center space-y-3">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, ease: easeSmooth }}
            className="font-mono text-xs uppercase tracking-widest text-neutral-400 font-semibold"
          >
            GET IN TOUCH
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.9, delay: 0.1, ease: easeSmooth }}
            className="font-display text-4xl sm:text-6xl md:text-7xl font-black tracking-tight text-white"
          >
            LET'S WORK TOGETHER
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.9, delay: 0.18, ease: easeSmooth }}
            className="font-sans text-sm sm:text-base text-neutral-400 max-w-lg"
          >
            Have a project in mind, looking for a frontend developer, or just want to connect? Let's build something remarkable.
          </motion.p>
        </div>

        {/* Two-Column Grid: Contact Info / Contact Form */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch pt-4">
          
          {/* Left Column: Direct Email CTA & Social Cards */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.9, delay: 0.2, ease: easeSmooth }}
            className="lg:col-span-5 flex flex-col justify-between space-y-6"
          >
            {/* Direct Email Card with Copy Action */}
            <div className="p-6 sm:p-8 rounded-[28px] bg-[#0c0c10] border border-white/[0.08] space-y-5 shadow-xl">
              <div className="w-12 h-12 rounded-2xl bg-white/[0.05] border border-white/10 flex items-center justify-center text-blue-400">
                <Mail className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <span className="font-mono text-xs text-neutral-500 uppercase tracking-wider">
                  Direct Email
                </span>
                <h3 className="font-display text-xl sm:text-2xl font-bold text-white">
                  rifqidev.contact@gmail.com
                </h3>
              </div>

              <div className="flex items-center gap-3 pt-2">
                <button
                  onClick={handleCopyEmail}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-full bg-white/[0.06] hover:bg-white/15 border border-white/10 text-neutral-200 hover:text-white font-mono text-xs font-medium transition-all"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400">Copied to clipboard!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy email address</span>
                    </>
                  )}
                </button>

                <a
                  href="mailto:rifqidev.contact@gmail.com"
                  className="p-2.5 rounded-full bg-white text-black hover:bg-neutral-200 transition-colors shadow-md"
                  aria-label="Send email"
                >
                  <ArrowUpRight className="w-4 h-4" />
                </a>
              </div>
            </div>

            {/* Social Channels List */}
            <div className="p-6 sm:p-8 rounded-[28px] bg-[#0c0c10] border border-white/[0.08] space-y-4 shadow-xl">
              <span className="font-mono text-xs text-neutral-500 uppercase tracking-wider block">
                Social Profiles & Networks
              </span>

              <div className="grid grid-cols-2 gap-3">
                {socialsData.slice(0, 4).map((social) => (
                  <a
                    key={social.id}
                    href={social.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-3 rounded-2xl bg-white/[0.03] hover:bg-white/[0.08] border border-white/[0.06] hover:border-white/15 transition-all flex items-center justify-between group"
                  >
                    <span className="font-sans text-xs font-medium text-neutral-300 group-hover:text-white">
                      {social.name}
                    </span>
                    <ArrowUpRight className="w-3.5 h-3.5 text-neutral-500 group-hover:text-white transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                  </a>
                ))}
              </div>
            </div>

          </motion.div>

          {/* Right Column: Clean Interactive Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.9, delay: 0.3, ease: easeSmooth }}
            className="lg:col-span-7"
          >
            <div className="p-6 sm:p-8 md:p-10 rounded-[28px] bg-[#0c0c10] border border-white/[0.08] shadow-2xl space-y-6">
              <div className="space-y-1">
                <h3 className="font-display text-xl sm:text-2xl font-bold text-white">
                  Send a Message
                </h3>
                <p className="font-sans text-xs sm:text-sm text-neutral-400">
                  I typically respond within 24 business hours.
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="font-mono text-xs text-neutral-400">Your Name</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Alex Morgan"
                      value={formState.name}
                      onChange={(e) => setFormState({ ...formState, name: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-neutral-600 focus:outline-none focus:border-white/30 focus:bg-white/[0.06] transition-all font-sans text-sm"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="font-mono text-xs text-neutral-400">Your Email</label>
                    <input
                      type="email"
                      required
                      placeholder="alex@company.com"
                      value={formState.email}
                      onChange={(e) => setFormState({ ...formState, email: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-neutral-600 focus:outline-none focus:border-white/30 focus:bg-white/[0.06] transition-all font-sans text-sm"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="font-mono text-xs text-neutral-400">Subject</label>
                  <input
                    type="text"
                    required
                    placeholder="Project Inquiry / Frontend Opportunity"
                    value={formState.subject}
                    onChange={(e) => setFormState({ ...formState, subject: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-neutral-600 focus:outline-none focus:border-white/30 focus:bg-white/[0.06] transition-all font-sans text-sm"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="font-mono text-xs text-neutral-400">Message</label>
                  <textarea
                    required
                    rows={4}
                    placeholder="Describe your project, timeline, or inquiries here..."
                    value={formState.message}
                    onChange={(e) => setFormState({ ...formState, message: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-white/[0.03] border border-white/10 text-white placeholder-neutral-600 focus:outline-none focus:border-white/30 focus:bg-white/[0.06] transition-all font-sans text-sm resize-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting || submitted}
                  className={`w-full py-3.5 rounded-full font-sans font-semibold text-sm transition-all duration-300 flex items-center justify-center gap-2 shadow-lg ${
                    submitted
                      ? 'bg-emerald-500 text-white'
                      : 'bg-white text-black hover:bg-neutral-200 shadow-white/10'
                  }`}
                >
                  {isSubmitting ? (
                    <span>Sending message...</span>
                  ) : submitted ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>Message Sent Successfully!</span>
                    </>
                  ) : (
                    <>
                      <span>Send Message</span>
                      <Send className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>
            </div>
          </motion.div>

        </div>

      </div>
    </section>
  );
};
