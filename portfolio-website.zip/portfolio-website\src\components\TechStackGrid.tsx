import React from 'react';
import { motion } from 'framer-motion';
import { techStackData, type TechItem } from '../data/techStack';
import { easeSmooth } from '../utils/animationVariants';

// Clean inline SVGs for authentic brand icons matching the reference
const renderTechIcon = (type: string, color: string) => {
  switch (type) {
    case 'react':
      return (
        <svg className="w-10 h-10" viewBox="0 0 115.3 100" fill={color}>
          <ellipse cx="57.65" cy="50" rx="14.4" ry="14.4" />
          <path d="M57.65,0 C33.8,0 14.4,22.4 14.4,50 C14.4,77.6 33.8,100 57.65,100 C81.5,100 100.9,77.6 100.9,50 C100.9,22.4 81.5,0 57.65,0 Z" fill="none" stroke={color} strokeWidth="4.5" transform="rotate(30 57.65 50)" />
          <path d="M57.65,0 C33.8,0 14.4,22.4 14.4,50 C14.4,77.6 33.8,100 57.65,100 C81.5,100 100.9,77.6 100.9,50 C100.9,22.4 81.5,0 57.65,0 Z" fill="none" stroke={color} strokeWidth="4.5" transform="rotate(90 57.65 50)" />
          <path d="M57.65,0 C33.8,0 14.4,22.4 14.4,50 C14.4,77.6 33.8,100 57.65,100 C81.5,100 100.9,77.6 100.9,50 C100.9,22.4 81.5,0 57.65,0 Z" fill="none" stroke={color} strokeWidth="4.5" transform="rotate(150 57.65 50)" />
        </svg>
      );
    case 'typescript':
      return (
        <div className="w-10 h-10 rounded-lg bg-[#3178C6] flex items-center justify-center text-white font-bold font-sans text-xl shadow-md">
          TS
        </div>
      );
    case 'tailwind':
      return (
        <svg className="w-10 h-10" viewBox="0 0 24 24" fill="none">
          <path d="M12.001 4.8c-3.2 0-5.2 1.6-6 4.8 1.2-1.6 2.6-2.2 4.2-1.8.913.228 1.565.89 2.288 1.624C13.666 10.618 15.027 12 18.001 12c3.2 0 5.2-1.6 6-4.8-1.2 1.6-2.6 2.2-4.2 1.8-.913-.228-1.565-.89-2.288-1.624C10.336 13.382 8.975 12 6.001 12zm-6 7.2c-3.2 0-5.2 1.6-6 4.8 1.2-1.6 2.6-2.2 4.2-1.8.913.228 1.565.89 2.288 1.624 1.177 1.194 2.538 2.576 5.512 2.576 3.2 0 5.2-1.6 6-4.8-1.2 1.6-2.6 2.2-4.2 1.8-.913-.228-1.565-.89-2.288-1.624C10.336 13.382 8.975 12 6.001 12z" fill="#38BDF8"/>
        </svg>
      );
    case 'html':
      return (
        <div className="w-10 h-10 rounded-lg bg-[#E34F26] flex items-center justify-center text-white font-black font-sans text-xl shadow-md">
          5
        </div>
      );
    case 'css':
      return (
        <div className="w-10 h-10 rounded-lg bg-[#1572B6] flex items-center justify-center text-white font-black font-sans text-xl shadow-md">
          3
        </div>
      );
    case 'php':
      return (
        <div className="w-12 h-8 rounded-full bg-[#777BB4] flex items-center justify-center text-white font-bold font-sans text-xs tracking-wider shadow-md">
          php
        </div>
      );
    case 'laravel':
      return (
        <svg className="w-10 h-10" viewBox="0 0 24 24" fill="none">
          <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" stroke="#FF2D20" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      );
    case 'nextjs':
      return (
        <div className="w-10 h-10 rounded-full bg-black border border-white/20 flex items-center justify-center text-white font-black font-sans text-lg shadow-md">
          N
        </div>
      );
    case 'javascript':
      return (
        <div className="w-10 h-10 rounded-lg bg-[#F7DF1E] flex items-center justify-center text-black font-black font-sans text-xl shadow-md">
          JS
        </div>
      );
    case 'mysql':
      return (
        <svg className="w-10 h-10" viewBox="0 0 24 24" fill="none">
          <path d="M4 16c2-4 6-8 12-6 2 1 4 0 5-1-1 3-3 6-6 7-4 1-8-1-11 0z" stroke="#4479A1" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          <path d="M14 6c-2 2-3 4-3 7" stroke="#00758F" strokeWidth="2" strokeLinecap="round"/>
        </svg>
      );
    case 'python':
      return (
        <svg className="w-10 h-10" viewBox="0 0 24 24" fill="none">
          <path d="M12 2c3 0 5 1 5 3v2H9c-2 0-3 1-3 3v2H4c-2 0-2-4 0-6 2-3 5-4 8-4zm0 20c-3 0-5-1-5-3v-2h8c2 0 3-1 3-3v-2h2c2 0 2 4 0 6-2 3-5 4-8 4z" fill="#3776AB"/>
          <circle cx="9" cy="5" r="1" fill="#fff" />
          <circle cx="15" cy="19" r="1" fill="#fff" />
        </svg>
      );
    case 'git':
      return (
        <svg className="w-10 h-10" viewBox="0 0 24 24" fill="none">
          <path d="M18 6a2 2 0 100-4 2 2 0 000 4zM6 18a2 2 0 100-4 2 2 0 000 4zM6 9a2 2 0 100-4 2 2 0 000 4z" fill="#F05032"/>
          <path d="M6 9v5M9 7l6 6" stroke="#F05032" strokeWidth="2" strokeLinecap="round"/>
        </svg>
      );
    case 'github':
      return (
        <svg className="w-10 h-10" viewBox="0 0 24 24" fill="#FFFFFF">
          <path d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.53 1.032 1.53 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z" />
        </svg>
      );
    case 'figma':
      return (
        <svg className="w-10 h-10" viewBox="0 0 24 24" fill="none">
          <path d="M8 2h8a4 4 0 014 4v0a4 4 0 01-4 4H8a4 4 0 01-4-4v0a4 4 0 014-4z" fill="#F24E1E" />
          <path d="M8 10h8a4 4 0 014 4v0a4 4 0 01-4 4H8a4 4 0 01-4-4v0a4 4 0 014-4z" fill="#A259FF" />
          <path d="M8 18a4 4 0 014-4h0a4 4 0 014 4v0a4 4 0 01-4 4H8a4 4 0 01-4-4z" fill="#0ACF83" />
        </svg>
      );
    case 'vite':
    default:
      return (
        <svg className="w-10 h-10" viewBox="0 0 24 24" fill="none">
          <path d="M12 2L2 6l10 16 10-16-10-4z" fill="#646CFF" />
          <path d="M12 4l-7 3 7 11 7-11-7-3z" fill="#FFD62E" />
        </svg>
      );
  }
};

export const TechStackGrid: React.FC = () => {
  return (
    <div className="w-full max-w-5xl mx-auto py-8 px-4 sm:px-6">
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 sm:gap-6">
        {techStackData.map((tech: TechItem, idx: number) => (
          <motion.div
            key={tech.id}
            initial={{ opacity: 0, y: 45 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{
              duration: 0.8,
              delay: idx * 0.07,
              ease: easeSmooth,
            }}
            whileHover={{
              y: -6,
              scale: 1.03,
              transition: { duration: 0.35, ease: 'easeOut' },
            }}
            className="group relative flex flex-col items-center justify-center p-6 rounded-[24px] bg-[#0c0c10] border border-white/[0.08] hover:border-white/20 hover:bg-[#111117] transition-colors duration-400 shadow-lg hover:shadow-[0_15px_40px_-10px_rgba(0,0,0,0.8),0_0_20px_rgba(255,255,255,0.05)] cursor-default"
          >
            {/* Ambient hover glow inside card */}
            <div
              className="absolute inset-0 rounded-[24px] opacity-0 group-hover:opacity-10 transition-opacity duration-500 pointer-events-none"
              style={{ backgroundColor: tech.color }}
            />

            {/* Brand Icon */}
            <div className="h-14 flex items-center justify-center transition-transform duration-400 group-hover:scale-110">
              {renderTechIcon(tech.iconType, tech.color)}
            </div>

            {/* Technology Name */}
            <span className="font-display text-sm sm:text-base font-semibold text-neutral-200 group-hover:text-white mt-4 transition-colors">
              {tech.name}
            </span>

            {/* Proficiency Tag */}
            <span className="font-mono text-[10px] text-neutral-500 uppercase tracking-widest mt-1">
              {tech.level}
            </span>
          </motion.div>
        ))}
      </div>
    </div>
  );
};
