export interface ProfileData {
  brand: string;
  name: {
    first: string;
    middle: string;
    last: string;
    full: string;
  };
  role: {
    primary: string;
    secondary: string;
    badge: string;
    commandLines: string[];
    techPills: string[];
  };
  availability: {
    status: string;
    available: boolean;
  };
  bio: {
    hero: string;
    about: string;
    quote: string;
  };
  stats: Array<{
    id: string;
    icon: string;
    label: string;
    value: string | number;
    linkTo?: string;
  }>;
  assets: {
    portrait: string;
    portraitAlt: string;
    cvFile: string;
  };
}

export const profileData: ProfileData = {
  brand: "rifqi.dev",
  name: {
    first: "Rifqi",
    middle: "Muhammad",
    last: "Aliya",
    full: "Rifqi Muhammad Aliya",
  },
  role: {
    primary: "Frontend",
    secondary: "Developer",
    badge: "Junior Programmer _",
    commandLines: [
      "/ explore my work below",
      "/ open to full-time & freelance opportunities",
    ],
    techPills: ["Typescript", "React.js", "Tailwind"],
  },
  availability: {
    status: "AVAILABLE FOR WORK",
    available: true,
  },
  bio: {
    hero: "Menciptakan website modern dengan tampilan clean, responsif, dan elegan. Mengubah ide dan desain menjadi pengalaman digital yang menarik dan mudah digunakan.",
    about: "Fresh Graduate SMK Rekayasa Perangkat Lunak lulusan 2026 dengan passion di bidang frontend development dan UI modern. Berfokus pada pembuatan website clean, responsif, dan visual yang kuat untuk menghadirkan pengalaman digital yang optimal.",
    quote: "Turning ideas into clean, modern, and meaningful digital experiences.",
  },
  stats: [
    {
      id: "projects",
      icon: "Code2",
      label: "PROJECTS",
      value: "6+",
      linkTo: "portfolio",
    },
    {
      id: "certificates",
      icon: "Award",
      label: "CERTIFICATES",
      value: "11",
      linkTo: "portfolio",
    },
    {
      id: "completed-works",
      icon: "Globe",
      label: "COMPLETED WORKS",
      value: "15+",
      linkTo: "portfolio",
    },
  ],
  assets: {
    portrait: "/assets/profile/profile.webp",
    portraitAlt: "Rifqi Muhammad Aliya - Frontend Developer",
    cvFile: "/assets/resume/resume.pdf",
  },
};
