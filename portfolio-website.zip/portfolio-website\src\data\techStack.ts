export interface TechItem {
  id: string;
  name: string;
  category: "frontend" | "backend" | "tools" | "languages";
  level: string;
  color: string;
  iconType: string;
}

export const techStackData: TechItem[] = [
  {
    id: "react",
    name: "React.js",
    category: "frontend",
    level: "Advanced",
    color: "#61DAFB",
    iconType: "react",
  },
  {
    id: "typescript",
    name: "TypeScript",
    category: "languages",
    level: "Proficient",
    color: "#3178C6",
    iconType: "typescript",
  },
  {
    id: "tailwind",
    name: "Tailwind",
    category: "frontend",
    level: "Advanced",
    color: "#38BDF8",
    iconType: "tailwind",
  },
  {
    id: "html",
    name: "HTML",
    category: "frontend",
    level: "Expert",
    color: "#E34F26",
    iconType: "html",
  },
  {
    id: "css",
    name: "CSS",
    category: "frontend",
    level: "Advanced",
    color: "#1572B6",
    iconType: "css",
  },
  {
    id: "php",
    name: "PHP",
    category: "backend",
    level: "Intermediate",
    color: "#777BB4",
    iconType: "php",
  },
  {
    id: "laravel",
    name: "Laravel",
    category: "backend",
    level: "Proficient",
    color: "#FF2D20",
    iconType: "laravel",
  },
  {
    id: "nextjs",
    name: "Next.js",
    category: "frontend",
    level: "Proficient",
    color: "#FFFFFF",
    iconType: "nextjs",
  },
  {
    id: "javascript",
    name: "JavaScript",
    category: "languages",
    level: "Advanced",
    color: "#F7DF1E",
    iconType: "javascript",
  },
  {
    id: "mysql",
    name: "MySQL",
    category: "backend",
    level: "Proficient",
    color: "#4479A1",
    iconType: "mysql",
  },
  {
    id: "python",
    name: "Python",
    category: "languages",
    level: "Intermediate",
    color: "#3776AB",
    iconType: "python",
  },
  {
    id: "git",
    name: "Git",
    category: "tools",
    level: "Advanced",
    color: "#F05032",
    iconType: "git",
  },
  {
    id: "github",
    name: "GitHub",
    category: "tools",
    level: "Advanced",
    color: "#FFFFFF",
    iconType: "github",
  },
  {
    id: "figma",
    name: "Figma",
    category: "tools",
    level: "Proficient",
    color: "#F24E1E",
    iconType: "figma",
  },
  {
    id: "vite",
    name: "Vite",
    category: "tools",
    level: "Advanced",
    color: "#646CFF",
    iconType: "vite",
  },
];
