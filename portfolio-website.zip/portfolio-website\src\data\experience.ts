export interface ExperienceItem {
  id: string;
  period: string;
  role: string;
  company: string;
  location: string;
  type: string;
  description: string;
  highlights: string[];
  technologies: string[];
}

export const experienceData: ExperienceItem[] = [
  {
    id: "exp-01",
    period: "2025 — 2026",
    role: "Frontend Developer Intern",
    company: "PT Cakrawala Global Yaksa",
    location: "Jakarta, Indonesia",
    type: "Internship / PKL",
    description: "Developed and optimized client-facing enterprise web interfaces, translated high-fidelity Figma designs into reusable React components, and improved application load times.",
    highlights: [
      "Built responsive dashboard modules with React.js and Tailwind CSS",
      "Collaborated with backend engineers to integrate RESTful API endpoints",
      "Optimized Core Web Vitals resulting in 35% faster page load metrics",
    ],
    technologies: ["React.js", "TypeScript", "Tailwind CSS", "REST API", "Git"],
  },
  {
    id: "exp-02",
    period: "2024 — Present",
    role: "Freelance Creative Developer & UI Engineer",
    company: "Independent / Digital Studios",
    location: "Remote",
    type: "Freelance & Contract",
    description: "Designing and developing bespoke web experiences for creative agencies, tech startups, and local businesses with an emphasis on minimalist design, smooth motion, and rock-solid responsiveness.",
    highlights: [
      "Delivered 15+ custom web projects with 100% client satisfaction",
      "Created modern landing pages with Framer Motion animations",
      "Configured continuous deployment pipelines using Vercel and GitHub Actions",
    ],
    technologies: ["Next.js", "React.js", "Tailwind CSS", "Framer Motion", "Laravel", "MySQL"],
  },
  {
    id: "exp-03",
    period: "2023 — 2026",
    role: "Software Engineering Student (RPL)",
    company: "SMK Rekayasa Perangkat Lunak",
    location: "Indonesia",
    type: "Formal Education",
    description: "Specialized in software engineering principles, fullstack web architecture, database management, and modern programming languages.",
    highlights: [
      "Ranked Top 5% in Web Application Competitions",
      "Led software development team for school administrative portal",
      "Graduated with National BNSP Software Competency Certification",
    ],
    technologies: ["HTML5", "CSS3", "JavaScript", "PHP", "Laravel", "MySQL", "Git"],
  },
];
