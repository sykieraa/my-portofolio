export interface CertificateItem {
  id: string;
  title: string;
  issuer: string;
  date: string;
  category: string;
  credentialId: string;
  image: string;
  skills: string[];
}

export const certificatesData: CertificateItem[] = [
  {
    id: "cert-01",
    title: "SERTIFIKAT PKL PT CAKRAWALA GLOBAL YAKSA",
    issuer: "PT Cakrawala Global Yaksa",
    date: "Desember 2025",
    category: "Industrial Internship",
    credentialId: "CGY-PKL-2025-089",
    image: "/assets/certificates/certificate-01.webp",
    skills: ["Frontend Development", "Web Application", "UI Implementation", "Collaboration"],
  },
  {
    id: "cert-02",
    title: "BELAJAR MEMBUAT FRONT-END WEB UNTUK PEMULA",
    issuer: "Dicoding Academy Indonesia",
    date: "Januari 2026",
    category: "Frontend Fundamentals",
    credentialId: "DICODING-FE-77491",
    image: "/assets/certificates/certificate-02.webp",
    skills: ["HTML5", "CSS3", "JavaScript ES6+", "DOM Manipulation", "Web Storage"],
  },
  {
    id: "cert-03",
    title: "MENJADI REACT WEB DEVELOPER EXPERT",
    issuer: "Dicoding Academy Indonesia",
    date: "Maret 2026",
    category: "React Architecture",
    credentialId: "DICODING-REACT-99201",
    image: "/assets/certificates/certificate-03.webp",
    skills: ["React Hooks", "Custom Hooks", "Redux & Context", "Performance Optimization", "Automated Testing"],
  },
  {
    id: "cert-04",
    title: "SERTIFIKASI KOMPETENSI REKAYASA PERANGKAT LUNAK",
    issuer: "Badan Nasional Sertifikasi Profesi (BNSP)",
    date: "Februari 2026",
    category: "National Competence Certification",
    credentialId: "BNSP-RPL-2026-4412",
    image: "/assets/certificates/certificate-04.webp",
    skills: ["Software Engineering", "System Analysis", "Database Design", "Code Quality"],
  },
  {
    id: "cert-05",
    title: "ADVANCED TYPESCRIPT & MODERN JAVASCRIPT",
    issuer: "Meta Front-End Professional Certificate",
    date: "November 2025",
    category: "JavaScript & TypeScript",
    credentialId: "META-TS-88402",
    image: "/assets/certificates/certificate-05.webp",
    skills: ["TypeScript Generics", "Type Narrowing", "Async Programming", "Design Patterns"],
  },
  {
    id: "cert-06",
    title: "TAILWIND CSS MASTERCLASS & DESIGN SYSTEMS",
    issuer: "Frontend Masters",
    date: "Oktober 2025",
    category: "UI/UX & CSS Architecture",
    credentialId: "FM-CSS-2025-103",
    image: "/assets/certificates/certificate-06.webp",
    skills: ["Tailwind CSS", "Design Tokens", "Responsive Layouts", "Dark Mode Architecture"],
  },
  {
    id: "cert-07",
    title: "WEB ACCESSIBILITY & PERFORMANCE OPTIMIZATION",
    issuer: "Google Developers Training",
    date: "Agustus 2025",
    category: "Web Performance & a11y",
    credentialId: "GOOGLE-A11Y-5519",
    image: "/assets/certificates/certificate-07.webp",
    skills: ["Lighthouse Auditing", "Core Web Vitals", "WCAG 2.1 AA", "ARIA Specifications"],
  },
  {
    id: "cert-08",
    title: "FULLSTACK WEB DEVELOPMENT WITH LARAVEL & REACT",
    issuer: "BuildWithAngga (BWA)",
    date: "Juni 2025",
    category: "Fullstack Development",
    credentialId: "BWA-LARA-REACT-661",
    image: "/assets/certificates/certificate-08.webp",
    skills: ["Laravel 11", "Inertia.js", "RESTful API", "MySQL", "Authentication"],
  },
  {
    id: "cert-09",
    title: "GIT & GITHUB COLLABORATIVE WORKFLOWS",
    issuer: "GitHub Education",
    date: "Mei 2025",
    category: "Version Control & DevOps",
    credentialId: "GH-ED-2025-3310",
    image: "/assets/certificates/certificate-09.webp",
    skills: ["Git Branching", "Merge Conflict Resolution", "GitHub Actions CI/CD", "Code Review"],
  },
  {
    id: "cert-10",
    title: "CLOUD PRACTITIONER FOUNDATIONS",
    issuer: "Amazon Web Services (AWS)",
    date: "April 2025",
    category: "Cloud Infrastructure",
    credentialId: "AWS-CPF-2025-9018",
    image: "/assets/certificates/certificate-10.webp",
    skills: ["AWS EC2", "S3 Storage", "CloudFront CDN", "IAM Security"],
  },
  {
    id: "cert-11",
    title: "UI/UX DESIGN & INTERACTION SYSTEMS WITH FIGMA",
    issuer: "Interaction Design Foundation",
    date: "Maret 2025",
    category: "UI/UX Design",
    credentialId: "IXDF-FIGMA-2025-11",
    image: "/assets/certificates/certificate-10.webp",
    skills: ["Figma Component Systems", "Auto Layout", "Micro-Interactions", "Wireframing"],
  },
];
