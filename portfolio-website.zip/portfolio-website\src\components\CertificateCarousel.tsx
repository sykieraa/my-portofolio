import React, { useRef, useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import type { CertificateItem } from '../data/certificates';
import { CertificateCard } from './CertificateCard';

interface CertificateCarouselProps {
  certificates: CertificateItem[];
  onSelectCertificate: (cert: CertificateItem) => void;
}

export const CertificateCarousel: React.FC<CertificateCarouselProps> = ({
  certificates,
  onSelectCertificate,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [activeIndex, setActiveIndex] = useState(0);

  const handleScroll = () => {
    if (!containerRef.current) return;
    const container = containerRef.current;
    const cardWidth = 360;
    const scrollLeft = container.scrollLeft;
    const newIndex = Math.round(scrollLeft / cardWidth);
    if (newIndex >= 0 && newIndex < certificates.length && newIndex !== activeIndex) {
      setActiveIndex(newIndex);
    }
  };

  const scrollToIndex = (index: number) => {
    if (!containerRef.current) return;
    const container = containerRef.current;
    const targetIndex = Math.max(0, Math.min(certificates.length - 1, index));
    const cards = container.children;
    if (cards[targetIndex]) {
      const card = cards[targetIndex] as HTMLElement;
      const offset = card.offsetLeft - container.offsetWidth / 2 + card.offsetWidth / 2;
      container.scrollTo({
        left: offset,
        behavior: 'smooth',
      });
      setActiveIndex(targetIndex);
    }
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      scrollToIndex(0);
    }, 100);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="relative w-full py-8">
      {/* Carousel Track */}
      <div
        ref={containerRef}
        onScroll={handleScroll}
        className="flex items-center gap-6 sm:gap-8 overflow-x-auto no-scrollbar py-8 px-4 sm:px-12 md:px-24 snap-x snap-mandatory scroll-smooth"
      >
        {certificates.map((cert, idx) => (
          <div key={cert.id} className="snap-center flex-shrink-0">
            <CertificateCard
              certificate={cert}
              isCenter={idx === activeIndex}
              onSelect={onSelectCertificate}
            />
          </div>
        ))}
      </div>

      {/* Floating Navigation Controls */}
      <div className="flex items-center justify-between max-w-xs mx-auto mt-6 px-4">
        <button
          onClick={() => scrollToIndex(activeIndex - 1)}
          disabled={activeIndex === 0}
          className={`p-3 rounded-full border transition-all duration-300 ${
            activeIndex === 0
              ? 'opacity-30 cursor-not-allowed border-white/5 bg-transparent text-neutral-600'
              : 'border-white/10 bg-[#121216] text-white hover:bg-white/10 hover:border-white/20'
          }`}
          aria-label="Previous certificate"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>

        {/* Dynamic Dot Indicators */}
        <div className="flex items-center gap-1.5 overflow-hidden max-w-[140px] justify-center">
          {certificates.map((_, idx) => (
            <button
              key={idx}
              onClick={() => scrollToIndex(idx)}
              className={`h-1.5 rounded-full transition-all duration-500 ${
                idx === activeIndex
                  ? 'w-5 bg-white shadow-[0_0_8px_rgba(255,255,255,0.8)]'
                  : 'w-1.5 bg-neutral-700 hover:bg-neutral-500'
              }`}
              aria-label={`Go to certificate ${idx + 1}`}
            />
          ))}
        </div>

        <button
          onClick={() => scrollToIndex(activeIndex + 1)}
          disabled={activeIndex === certificates.length - 1}
          className={`p-3 rounded-full border transition-all duration-300 ${
            activeIndex === certificates.length - 1
              ? 'opacity-30 cursor-not-allowed border-white/5 bg-transparent text-neutral-600'
              : 'border-white/10 bg-[#121216] text-white hover:bg-white/10 hover:border-white/20'
          }`}
          aria-label="Next certificate"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
